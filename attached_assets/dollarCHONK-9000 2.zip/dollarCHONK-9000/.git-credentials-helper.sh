#!/bin/bash

read url
echo url=$url
echo username=$GITHUB_USERNAME
echo password=$GITHUB_TOKEN