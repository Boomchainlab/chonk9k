
# $TRUMP47 Token

> **Make Memecoins Great Again.**

Official repository for $TRUMP47: the meme-driven, politically-fueled token to disrupt the crypto narrative.

## Quick Links
- [Website](https://boomchainlab.github.io/trump47-token)
- [Whitepaper](whitepaper.html)

## License
MIT License
