#!/bin/bash

set -e

echo "Updating Browserslist database..."
npx update-browserslist-db@latest --yes

echo "Browserslist database successfully updated."
